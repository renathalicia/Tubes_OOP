# Tubes_OOP

Cara menjalankan sementara;

javac -d bin main/*.java entity/*.java
java -cp bin main.Main  